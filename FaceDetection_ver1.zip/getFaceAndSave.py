# 얼굴만 떼내기
# Written by Kim7obu, ANU 20181107 Kim Ju Hyeon

import cv2
import mediapipe as mp
import time
import math


cap = cv2.VideoCapture(0)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
pTime = 0
cTime = 0

mpFaceDetection = mp.solutions.face_detection
mpDraw = mp.solutions.drawing_utils
faceDetection = mpFaceDetection.FaceDetection(0.75)

# 사진 장수 세는 용도의 count
count = 0
maxCount = 300
face_id = input('\n enter UserID by Integer (ex. 1, 2, 3,...): ')
print("\n Face Capture Initiated. Wait till the full on [" + str(maxCount) + "] pictures.")

# 100장 단위로 현재 몇장째인지 출력해주는 함수
def counterPrinter():
    status = " picture captured."
    left = " picture left."
    cv2.putText(img, "Caputre Initiated. Keep look at the Camera", (200, 23), cv2.FONT_HERSHEY_PLAIN, 2,
                (0, 255, 0), 2)
    for i in range(1, maxCount//100):
        if ((count//100)==i):
            cv2.putText(img, str(int(math.sqrt((count//100)*i)*100)) + status, (200, 50), cv2.FONT_HERSHEY_PLAIN, 2, (255, 50, 0), 2)
            cv2.putText(img, str(int(maxCount - (math.sqrt((count//100) * i) * 100))) + left, (200, 80), cv2.FONT_HERSHEY_PLAIN, 2,
                        (0, 0, 255), 2)
while True:
    success, img = cap.read()
    imgRGB = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    results = faceDetection.process(imgRGB)

    if results.detections:
        for id, detection in enumerate(results.detections):
            bboxC = detection.location_data.relative_bounding_box  # bounding box class
            ih, iw, ic = img.shape  # 이미지 height, width, channel
            x = int(bboxC.xmin * iw)
            y = int(bboxC.ymin * ih)
            w = int(bboxC.width * iw)
            h = int(bboxC.height * ih)
            bbox = x, y, w, h
            cv2.rectangle(img, bbox, (255, 0, 255), 1)
            cv2.putText(img, f'{int(detection.score[0] * 100)}%', (bbox[0], bbox[1] - 20), cv2.FONT_HERSHEY_PLAIN, 3,
                        (255, 0, 255), 3)

            # 얼굴 갯수 + 사진 저장
            count += 1
            gray_img = cv2.cvtColor(imgRGB, cv2.COLOR_BGR2GRAY)                         # 전체 사진
            gray_img_onlyface = gray_img[(y+2):(y + h-2), (x+2):(x + w-2)]              # 얼굴만
            gray_img_smolcroped = gray_img[(y - 150):(y + h + 100), (x - 100):(x + w +100)]  # 얼굴 + 배경

            if (count%3 == 1): #얼굴만
                cv2.imwrite("faces_ver1/User." + str(face_id) + '.' + str(count) + ".jpg",
                        gray_img_onlyface, params=[cv2.IMWRITE_JPEG_QUALITY, 100])
            elif(count%3 == 2): #얼굴+배경
                cv2.imwrite("faces_ver1/User." + str(face_id) + '.' + str(count) + ".jpg",
                        gray_img_smolcroped, params=[cv2.IMWRITE_JPEG_QUALITY, 100])
            else: # 전체 사진
                cv2.imwrite("faces_ver1/User." + str(face_id) + '.' + str(count) + ".jpg",
                            gray_img, params=[cv2.IMWRITE_JPEG_QUALITY, 100])


    cTime = time.time()
    fps = 1 / (cTime - pTime)
    pTime = cTime

    counterPrinter()

    cv2.putText(img, str(int(fps)), (70, 50), cv2.FONT_HERSHEY_PLAIN, 3, (0, 255, 0), 3)
    cv2.imshow("Image", img)
    cv2.waitKey(1)

    k = cv2.waitKey(10) & 0xff  # Press 'ESC' for exiting video
    if k == 27:
        break
    elif count == maxCount:
        break
# Do a bit of cleanup
print("\n [Python Console] Exiting entire program and cleaning.")
cap.release()
cv2.destroyAllWindows()
print("\n [Python Console] Execute Complete")