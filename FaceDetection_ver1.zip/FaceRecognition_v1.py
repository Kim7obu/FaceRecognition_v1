# 미디어파이프 얼굴검출 + 하르카스케이드 얼굴인식
# Written by Kim7obu, ANU 20181107 Kim Ju Hyeon

import cv2
import mediapipe as mp
import time

cap = cv2.VideoCapture(0)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
minW = 0.1 * cap.get(cv2.CAP_PROP_FRAME_WIDTH)
minH = 0.1 * cap.get(cv2.CAP_PROP_FRAME_HEIGHT)

pTime = 0
cTime = 0

mpFaceDetection = mp.solutions.face_detection
mpDraw = mp.solutions.drawing_utils
faceDetection = mpFaceDetection.FaceDetection(0.75)

# HaarCascade로 훈련된 trainer.yml 파일이 들어가있는 경로를 불러옴 + HaarCascade 파일 불러옴
recognizer = cv2.face.LBPHFaceRecognizer_create()
recognizer.read('trainer/trainer_ver1.yml')  # 현재 상태에선 ver1 사용함.
cascadePath = "haarcascade_frontalface_default.xml"
faceCascade = cv2.CascadeClassifier(cascadePath);

# 사용자 이름
names = ['None', 'KimJuHyeon', 'KimJiAhn']
id = 0

while True:
    success, img = cap.read()
    imgRGB = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    results_mp = faceDetection.process(imgRGB)

    # 하르 그레이스케일
    results_haar = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # 하르카스케이드 관련 설정
    faces = faceCascade.detectMultiScale(
        results_haar,
        scaleFactor=1.2,
        minNeighbors=5,
        minSize=(int(minW), int(minH))
    )

    # 미디어파이프로 얼굴 검출이 성공하면
    if results_mp.detections:
        for id, detection in enumerate(results_mp.detections):
            bboxC = detection.location_data.relative_bounding_box  # bounding box class
            ih, iw, ic = img.shape  # 이미지 height, width, channel
            x = int(bboxC.xmin * iw)
            y = int(bboxC.ymin * ih)
            w = int(bboxC.width * iw)
            h = int(bboxC.height * ih)
            bbox = x, y, w, h
            cv2.rectangle(img, bbox, (255, 0, 255), 2)

            #  하르카스케이드 이용하여 얼굴 판단
            for (x, y, w, h) in faces:
                id, confidence = recognizer.predict(results_haar[y:y + h, x:x + w])
                if ((100 - confidence) >= 70):
                    id = names[id]
                elif ((100 - confidence) < 70):
                    id = "unknown"
                confidence = "  {0}%".format(round(100 - confidence))
                cv2.putText(img, str(id), (x + 2, y), cv2.FONT_HERSHEY_PLAIN, 3, (255, 255, 255), 2)
                cv2.putText(img, str(confidence), (x + 5, y + h), cv2.FONT_HERSHEY_PLAIN, 3, (255, 255, 0), 1)

    cTime = time.time()
    fps = 1 / (cTime - pTime)
    pTime = cTime

    cv2.putText(img, str(int(fps)), (70, 50), cv2.FONT_HERSHEY_PLAIN, 3, (0, 255, 0), 3)
    cv2.imshow("Image", img)
    cv2.waitKey(1)

    k = cv2.waitKey(10) & 0xff  # Press 'ESC' for exiting video
    if k == 27:
        break

# 창 닫기
print("\n [Python Console] Exiting entire program and cleaning.")
cap.release()
cv2.destroyAllWindows()
print("\n [Python Console] Execute Complete")